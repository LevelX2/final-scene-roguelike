# Final Scene Consumables SVG 128 (No Ring)

Diese Fassung nutzt freigestellte Gegenstände im World-Loot-Stil:
- kein Kreis
- kein Badge
- kein Emblem
- 128x128 SVG
- transparenter Hintergrund

Jede Datei zeigt ein physisches Einzelobjekt, das auf dem Boden oder in einer Kiste liegen könnte.
